# L0 热记忆 - 最后更新 2026-04-23 03:11
<!-- AI每次完成任务后，必须在这里追加一行 -->

## 当前项目
- **项目**：寻仙游戏 (hglua)
- **类型**：回合制游戏开发
- **核心文件**：XunXianBattle.lua（战斗钩子）

## 编码规则（必须遵守）
| 类型 | 编码 | 示例 |
|------|------|------|
| data/目录 | GBK | npc.txt, enemy.txt, itemset.txt |
| 代码文件 | UTF-8 | *.lua, *.py, *.js |
| 规则/知识文件 | UTF-8 | rules/*.md, knowledge/*.md |
| registry.json | GBK | rules/registry.json |

## 核心API（来自 cgmsv-lua-core.md）
- `Char.GetData(charIndex, dataType)` - 获取角色数据
- `Char.GiveItem(charIndex, itemId, count)` - 给予物品
- `NLG.ShowWindowTalked(npcIndex, msgType, msgId, ...)` - NPC对话
- `Item.SetData(itemIndex, dataType, value)` - 设置物品属性
- `Field.Get(fieldIndex, dataType)` - 获取地图数据
- `Field.Set(fieldIndex, dataType, value)` - 设置地图数据
- `NL.CreateNpc(...)` - 创建NPC

## 当前状态
- **开发进度**：基础战斗系统开发中
- **最近完成**：NPC任务触发逻辑
- **待处理**：战斗钩子与NPC脚本联动调试

## 经验教训（按时间倒序）
- [2026-04-23] **AI必须遵守规则第4步"记录结果"**，不能跳过
- [2026-04-22] **读取 registry.json 必须用 GBK 编码**，否则乱码
- [2026-04-22] **data/ 下的 txt 文件用 Tab 分隔**，不是空格
- [2026-04-22] **global-index.json 是场景路由表**，按需加载就靠它

## 系统架构
```
AGENTS.md（入口）
  ↓
global-index.json（场景路由）
  ↓
registry.json（完整索引）
  ↓
rules/ + knowledge/（按需加载）
  ↓
memory/l0_hot.md（更新结果）
```

## 本次工作记录（2026-04-23）
- [01:30] 完成chaonao系统完整验证（441个文件）
- [01:30] 修复问题：`rules/coding.md`不存在 → 改为`rules/project.md`
- [01:30] 修复global-index.json和AGENTS.md的断裂引用
- [01:30] 创建VERIFICATION.md（自验证提示词）、VALIDATION.md（验证报告）
- [01:37] **教训**：未按规则第4步记录结果，已补记
- [02:46] AGENTS.md升级为速查卡，去除冗余说明
- [02:46] chaonao核心规则写入AI长期记忆（MEMORY.md），实现自动加载
- [02:49] **超脑规则自检**：AGENTS.md场景从7个扩展到11个，补充完整规则索引
- [02:49] **超脑规则自检**：修复AGENTS.md与registry.json的场景不一致问题
- [02:49] **超脑规则自检**：全部56个注册文件验证通过，无缺失
- [03:11] **完善Game Studio调用**：AGENTS.md新增35个Agent + 72个Skill + 11个规则文件的按需加载表
