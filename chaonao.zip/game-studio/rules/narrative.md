---

> **File References**:
> - Caller: AGENTS.md -> registry.json(RULE-016) -> load this file
> - Registry: rules/registry.json RULE-016
> - Trigger scenes: GAME_DESIGN
> - Related: RULE-001, RULE-002, RULE-003
paths:
  - "design/narrative/**"
---

# Narrative Rules

- All new lore must be cross-referenced against existing lore for contradictions
- Every lore entry must specify canon level: Established / Provisional / Under Review
- Character dialogue must match the voice profile defined for that character
- World rules (what is possible/impossible) must be explicitly documented and consistent
- Mysteries must have documented "true answers" even if players never learn them
- Faction motivations, relationships, and power structures must be internally logical
- All narrative text must be localization-ready: no idioms that don't translate, named placeholders for variables
- No line of dialogue should exceed 120 characters for dialogue box constraints
