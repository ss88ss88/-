---

> **File References**:
> - Caller: AGENTS.md -> registry.json(RULE-010) -> load this file
> - Registry: rules/registry.json RULE-010
> - Trigger scenes: GAME_TASK
> - Related: RULE-001, RULE-002, RULE-003
paths:
  - "src/ui/**"
---

# UI Code Rules

- UI must NEVER own or directly modify game state — display only, use commands/events to request changes
- All UI text must go through the localization system — no hardcoded user-facing strings
- Support both keyboard/mouse AND gamepad input for all interactive elements
- All animations must be skippable and respect user motion/accessibility preferences
- UI sounds trigger through the audio event system, not directly
- UI must never block the game thread
- Scalable text and colorblind modes are mandatory, not optional
- Test all screens at minimum and maximum supported resolutions
