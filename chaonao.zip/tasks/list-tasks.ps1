# ============================================================
# 任务查看工具 - 查看任务池状态
# 路径: C:\Users\Administrator\Desktop\hglua\修仙创意\chaonao\tasks\list-tasks.ps1
# ============================================================
# 使用方法:
#   查看所有任务: .\list-tasks.ps1
#   只看P0任务:  .\list-tasks.ps1 -Priority P0
# ============================================================

param(
    [ValidateSet("P0", "P1", "P2", "P3", "All")]
    [string]$Priority = "All"
)

$BASE_DIR = "C:\Users\Administrator\Desktop\hglua\修仙创意\chaonao"
$TASK_POOL = "$BASE_DIR\tasks\task-pool.json"
$STATE_FILE = "$BASE_DIR\state\system-state.json"

function Load-Json {
    param([string]$Path)
    if (Test-Path $Path) {
        return Get-Content $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    }
    return $null
}

# 加载数据
$taskPool = Load-Json $TASK_POOL
$state = Load-Json $STATE_FILE

Write-Host ""
Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "         AI 守护进程 - 任务池状态" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# 系统状态
Write-Host "【系统状态】" -ForegroundColor Yellow
Write-Host "  当前状态: $($state.state.current_scene)"
Write-Host "  当前任务: $($state.state.current_task)"
Write-Host "  执行次数: $($state.state.execution_count)"
Write-Host "  熔断失败: $($state.circuit_breaker.consecutive_failures)/$($state.circuit_breaker.max_failures)"
Write-Host ""

# 队列统计
Write-Host "【任务队列】" -ForegroundColor Yellow
Write-Host "  P0紧急: $($taskPool.queue.p0_urgent.Count) 个"
Write-Host "  P1高优: $($taskPool.queue.p1_high.Count) 个"
Write-Host "  P2中优: $($taskPool.queue.p2_medium.Count) 个"
Write-Host "  P3低优: $($taskPool.queue.p3_low.Count) 个"
Write-Host ""

# 历史统计
Write-Host "【历史统计】" -ForegroundColor Yellow
Write-Host "  已完成: $($taskPool.tasks.completed.Count) 个"
Write-Host "  已失败: $($taskPool.tasks.failed.Count) 个"
Write-Host ""

# 详细列表
if ($Priority -eq "All" -or $Priority -eq "P0") {
    if ($taskPool.queue.p0_urgent.Count -gt 0) {
        Write-Host "【P0 紧急任务】" -ForegroundColor Red
        $taskPool.queue.p0_urgent | ForEach-Object {
            Write-Host "  🔴 $($_.name)" -ForegroundColor Red
            if ($_.description) { Write-Host "     $($_.description)" -ForegroundColor Gray }
        }
        Write-Host ""
    }
}

if ($Priority -eq "All" -or $Priority -eq "P1") {
    if ($taskPool.queue.p1_high.Count -gt 0) {
        Write-Host "【P1 高优先级】" -ForegroundColor Magenta
        $taskPool.queue.p1_high | ForEach-Object {
            Write-Host "  🟣 $($_.name)" -ForegroundColor Magenta
        }
        Write-Host ""
    }
}

if ($Priority -eq "All") {
    if ($taskPool.queue.p2_medium.Count -gt 0) {
        Write-Host "【P2 中优先级】" -ForegroundColor Yellow
        $taskPool.queue.p2_medium | ForEach-Object {
            Write-Host "  🟡 $($_.name)"
        }
        Write-Host ""
    }
    
    if ($taskPool.queue.p3_low.Count -gt 0) {
        Write-Host "【P3 低优先级】" -ForegroundColor Gray
        $taskPool.queue.p3_low | ForEach-Object {
            Write-Host "  ⚪ $($_.name)"
        }
        Write-Host ""
    }
}

# 最近完成
if ($taskPool.tasks.completed.Count -gt 0) {
    Write-Host "【最近完成】" -ForegroundColor Green
    $taskPool.tasks.completed | Select-Object -Last 5 | ForEach-Object {
        $time = [DateTime]::Parse($_.completed_at).ToString("MM-dd HH:mm")
        Write-Host "  ✅ [$time] $($_.name)"
    }
    Write-Host ""
}

# 最近失败
if ($taskPool.tasks.failed.Count -gt 0) {
    Write-Host "【最近失败】" -ForegroundColor Red
    $taskPool.tasks.failed | Select-Object -Last 3 | ForEach-Object {
        $time = [DateTime]::Parse($_.failed_at).ToString("MM-dd HH:mm")
        Write-Host "  ❌ [$time] $($_.name)"
    }
    Write-Host ""
}

Write-Host "═══════════════════════════════════════════════" -ForegroundColor Cyan
