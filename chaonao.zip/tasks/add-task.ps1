# ============================================================
# 任务添加工具 - 向任务池添加新任务
# 路径: C:\Users\Administrator\Desktop\hglua\修仙创意\chaonao\tasks\add-task.ps1
# ============================================================
# 使用方法:
#   添加P0紧急任务: .\add-task.ps1 -Name "紧急修复" -Priority P0
#   添加P1高优先级: .\add-task.ps1 -Name "开发战斗系统" -Priority P1
#   添加常规任务:   .\add-task.ps1 -Name "优化AI" -Priority P2
# ============================================================

param(
    [Parameter(Mandatory=$true)]
    [string]$Name,
    
    [ValidateSet("P0", "P1", "P2", "P3")]
    [string]$Priority = "P2",
    
    [string]$Description = "",
    
    [string]$TaskType = "generic",
    
    [hashtable]$Metadata = @{}
)

$BASE_DIR = "C:\Users\Administrator\Desktop\hglua\修仙创意\chaonao"
$TASK_POOL = "$BASE_DIR\tasks\task-pool.json"

function Load-Json {
    param([string]$Path)
    if (Test-Path $Path) {
        return Get-Content $Path -Raw -Encoding UTF8 | ConvertFrom-Json
    }
    return $null
}

function Save-Json {
    param([string]$Path, [object]$Data)
    $Data | ConvertTo-Json -Depth 10 | Set-Content -Path $Path -Encoding UTF8
}

# 加载任务池
$taskPool = Load-Json $TASK_POOL
if (-not $taskPool) {
    Write-Error "无法加载任务池: $TASK_POOL"
    exit 1
}

# 创建新任务
$newTask = @{
    id = [guid]::NewGuid().ToString()
    name = $Name
    description = $Description
    type = $TaskType
    priority = $Priority
    created_at = (Get-Date).ToString("o")
    metadata = $Metadata
}

# 根据优先级添加到对应队列
$queueName = switch ($Priority) {
    "P0" { "p0_urgent" }
    "P1" { "p1_high" }
    "P2" { "p2_medium" }
    "P3" { "p3_low" }
}

$taskPool.queue.$queueName += @($newTask)
$taskPool.updated = (Get-Date).ToString("o")

# 保存
Save-Json $TASK_POOL $taskPool

Write-Host "✅ 任务已添加" -ForegroundColor Green
Write-Host "   名称: $Name"
Write-Host "   优先级: $Priority"
Write-Host "   队列: $queueName"
Write-Host "   ID: $($newTask.id)"
