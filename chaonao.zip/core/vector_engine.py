# -*- coding: utf-8 -*-
import chromadb
from chromadb.utils import embedding_functions

class VectorMemoryEngine:
    def __init__(self, persist_dir="./index/vector_db"):
        self.client = chromadb.PersistentClient(path=persist_dir)
        self.ef = embedding_functions.DefaultEmbeddingFunction()
        self.memory_coll = self.client.get_or_create_collection(
            name="agent_memory",
            embedding_function=self.ef
        )

    def add_memory(self, mem_id: str, content: str, meta: dict):
        self.memory_coll.add(
            ids=[mem_id],
            documents=[content],
            metadatas=[meta]
        )

    def search(self, query: str, top_k=5):
        res = self.memory_coll.query(
            query_texts=[query],
            n_results=top_k
        )
        return {
            "ids": res.get("ids", [[]])[0],
            "documents": res.get("documents", [[]])[0],
            "metadatas": res.get("metadatas", [[]])[0]
        }

if __name__ == "__main__":
    engine = VectorMemoryEngine()
    engine.add_memory(
        mem_id="mem_001",
        content="Agent framework uses file mailbox for multi-agent communication",
        meta={"layer": "L3", "priority": "P1", "type": "architecture"}
    )
    result = engine.search("How do agents collaborate")
    print(result)
