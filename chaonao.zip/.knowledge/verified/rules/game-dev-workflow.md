# 游戏开发工作流 - 记忆宫殿 + Game Studio 融合版

> 本文档定义如何将记忆宫殿的场景识别机制与 Claude Code Game Studio 的工作流无缝结合。
> 
> **文件指向关系**：
> - 调用者：AGENTS.md → registry.json → 场景匹配 → 加载本文件(KNOW-021)
> - 被调用者：game-start-skill.md（入口Skill）在阶段4路由后引用本工作流
> - 同级文件：game-start-skill.md（入口Skill）、registry.json（场景配置）
> - 上级索引：rules/registry.json KNOW-021条目

## 工作流总览

```
用户需求 → 记忆宫殿场景识别 → 加载对应规则/知识 → 激活Game Studio Agent → 执行Skill → 记录经验到记忆宫殿
```

## 阶段映射表

| Game Studio 阶段 | 记忆宫殿场景 | 触发关键词 | 核心Agent | 核心Skill |
|-----------------|------------|-----------|----------|----------|
| Concept | GAME_DESIGN | 游戏创意, 想法, 概念 | Creative Director, Game Designer | /brainstorm, /map-systems |
| Systems Design | GAME_DESIGN | 系统设计, GDD | Game Designer, Systems Designer | /design-system, /design-review |
| Technical Setup | GAME_TASK | 架构, 技术选型 | Technical Director, Lead Programmer | /create-architecture, /setup-engine |
| Pre-Production | GAME_TASK | 原型, UX, 测试 | Prototyper, UX Designer | /prototype, /ux-design, /playtest-report |
| Production | GAME_TASK | 开发, 实现, 功能 | Gameplay Programmer, Engine Programmer | /dev-story, /code-review, /sprint-plan |
| Polish | GAME_QA | 优化, 平衡, 性能 | Performance Analyst, QA Lead | /perf-profile, /balance-check |
| Release | GAME_QA | 发布, 上线 | Release Manager, QA Lead | /release-checklist, /launch-checklist |

## 执行流程（每次游戏开发任务）

### 步骤1：场景识别（记忆宫殿）
读取 `rules/registry.json` 的 `scenes` 配置，根据用户输入匹配场景：
- 包含"游戏"+"开发/做/写" → GAME_TASK
- 包含"设计/GDD/策划" → GAME_DESIGN  
- 包含"测试/QA/Bug" → GAME_QA

### 步骤2：加载规则与知识
根据匹配的场景，从 registry.json 加载：
- `load_rules` → 规则文件路径
- `load_knowledge` → 知识文件路径
- `load_mistakes` → 预防措施
- `load_game_studio` → Agent/Skill配置

### 步骤3：检测项目阶段
执行 `/project-stage-detect` 或手动检测：
```
检查项：
- design/gdd/game-concept.md 存在？ → 概念阶段已完成
- design/gdd/systems-index.md 存在？ → 系统映射已完成
- docs/architecture/architecture.md 存在？ → 架构已完成
- production/sprints/ 有文件？ → 已进入生产阶段
- src/ 有代码？ → 已有实现
```

### 步骤4：匹配Agent
根据阶段和任务类型，从 registry.json 的 `game_studio.agents` 选择：

**概念阶段**：
- 主Agent：Creative Director (GS-001)
- 辅助：Game Designer (GS-004), Narrative Director (GS-008)

**架构阶段**：
- 主Agent：Technical Director (GS-002)
- 辅助：Lead Programmer (GS-005), 对应引擎专家

**生产阶段**：
- 主Agent：Lead Programmer (GS-005)
- 辅助：Gameplay Programmer (GS-012), 对应领域专家

**QA阶段**：
- 主Agent：QA Lead (GS-009)
- 辅助：QA Tester (GS-031), Performance Analyst (GS-027)

### 步骤5：执行Skill
根据阶段选择对应Skill，按 workflow-catalog.yaml 的顺序执行：

**概念阶段流程**：
```
/brainstorm → /setup-engine → /art-bible → /map-systems
```

**系统设计流程**：
```
/design-system (每个系统) → /design-review (每个系统) → /review-all-gdds → /consistency-check
```

**技术设置流程**：
```
/create-architecture → /architecture-decision (至少3个ADR) → /architecture-review → /create-control-manifest
```

**预生产流程**：
```
/ux-design → /prototype → /playtest-report → /create-epics → /create-stories → /sprint-plan
```

**生产流程**（循环）：
```
/sprint-plan → /story-readiness → /dev-story → /code-review → /story-done → (下一个story)
```

### 步骤6：记录经验（记忆宫殿学习闭环）
每个Skill执行后：
- 成功 → 记录到 `.learnings/LEARNINGS.md` [GAME_BEST]
- 失败 → 记录到 `.learnings/ERRORS.md` [GAME_ERROR]
- 发现更好做法 → 记录到 `.learnings/LEARNINGS.md` [GAME_IMPROVE]
- 每次变更追加到 `.learnings/CHANGELOG.md`

## 场景详细流程

### GAME_TASK（游戏工作坊）

**触发**：用户提到"开发游戏功能"、"实现XX系统"、"写游戏代码"

**加载**：
- 规则：RULE-001,002,004,005,006,007,008,009,010,011,012,013,014,015
- 知识：KNOW-012~020（Game Studio全部知识）
- 工作室：agents + skills + rules

**执行**：
1. 检测项目当前阶段
2. 加载对应阶段的Agent
3. 按workflow-catalog执行对应Skill
4. 验证输出
5. 记录经验

### GAME_DESIGN（游戏设计室）

**触发**：用户提到"游戏设计"、"GDD"、"系统设计"、"关卡设计"

**加载**：
- 规则：RULE-001,002,011,016
- 知识：KNOW-012,015,016,017,018,019
- 工作室：agents + skills

**执行**：
1. 激活 Creative Director 模式
2. 使用 Vision Articulation Framework 明确游戏愿景
3. 调用 Game Designer 进行系统设计
4. 生成GDD文档（8个必需部分）
5. 执行 /design-review 验证
6. 记录设计决策

### GAME_QA（游戏QA室）

**触发**：用户提到"测试"、"Bug"、"性能"、"平衡"

**加载**：
- 规则：RULE-001,002,013
- 知识：KNOW-012,013,015
- 工作室：agents + skills

**执行**：
1. 激活 QA Lead 模式
2. 生成测试计划（/qa-plan）
3. 执行测试（/smoke-check /regression-suite）
4. 生成报告（/playtest-report）
5. 记录问题到记忆宫殿 mistakes/

## 记忆宫殿与工作室的协作机制

### 1. 场景识别 → Agent激活
记忆宫殿的场景识别是"开关"，决定激活哪个工作室Agent。

### 2. 知识管理 → Skill输入
记忆宫殿的 verified knowledge 作为 Skill 的输入上下文。
例如：执行 /dev-story 时，先加载 KNOW-013（编码标准）作为约束。

### 3. 错误预防 → Mistakes加载
记忆宫殿的 mistakes/ 作为工作室的预防清单。
例如：GAME_QA 场景自动加载 MIST-004（预防措施）。

### 4. 经验记录 → 双重学习闭环
- 工作室的 Hook 验证结果 → 存入 mistakes/
- AI的经验记录 → 存入 LEARNINGS.md
- 两者结合形成完整的学习闭环

### 5. 目标池 → 生产驱动
记忆宫殿的 `tasks/task-pool.json` 驱动工作室的 Sprint 计划。
/sprint-plan 从目标池读取优先级最高的任务。

## 快速参考卡片

### 用户说"帮我开发一个游戏"
→ 场景：GAME_TASK
→ 阶段检测：新项目
→ Agent：Creative Director + Producer
→ Skill：/start → /brainstorm
→ 输出：game-concept.md

### 用户说"设计一个战斗系统"
→ 场景：GAME_DESIGN
→ Agent：Game Designer + Systems Designer
→ Skill：/design-system
→ 输出：design/gdd/systems/combat.md

### 用户说"实现玩家移动功能"
→ 场景：GAME_TASK
→ 阶段检测：生产阶段
→ Agent：Gameplay Programmer
→ Skill：/dev-story
→ 输出：src/ 中的代码 + story 状态更新

### 用户说"测试一下游戏性能"
→ 场景：GAME_QA
→ Agent：Performance Analyst + QA Lead
→ Skill：/perf-profile
→ 输出：性能分析报告
