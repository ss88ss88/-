# 游戏开发入口 Skill - 记忆宫殿融合版

> 当用户提到"游戏开发"、"做游戏"、"开发游戏"时激活此Skill。
> 融合记忆宫殿场景识别 + Game Studio工作流。
> 
> **文件指向关系**：
> - 调用者：AGENTS.md → registry.json → 场景匹配 → 加载本文件(KNOW-022)
> - 被调用者：game-dev-workflow.md（工作流）在阶段3后引用本入口Skill的路由结果
> - 同级文件：game-dev-workflow.md（工作流）、registry.json（场景配置）
> - 上级索引：rules/registry.json KNOW-022条目

## 激活条件

用户输入包含以下任一关键词：
- "游戏" + ("开发" | "做" | "写" | "创建" | "实现")
- "game" + ("dev" | "develop" | "create" | "make")
- "开发游戏" | "做游戏" | "写游戏"

## 执行流程

### 阶段1：记忆宫殿场景识别

1. 读取 `rules/registry.json`
2. 匹配 `scenes` 配置，确定场景类型：
   - GAME_TASK → 游戏开发任务
   - GAME_DESIGN → 游戏设计任务  
   - GAME_QA → 游戏测试任务
3. 加载对应场景的规则/知识/预防措施

### 阶段2：项目状态检测

在询问用户之前，先静默检测项目状态：

**检测项**：
- 引擎配置：读取 `game-studio/.claude/docs/technical-preferences.md` 或 `.claude/docs/technical-preferences.md`
- 游戏概念：检查 `design/gdd/game-concept.md` 是否存在
- 源代码：在 `src/` 中搜索源文件（`*.lua`, `*.gd`, `*.cs`, `*.cpp`, `*.h`, `*.rs`, `*.py`, `*.js`, `*.ts`）
- 原型：检查 `prototypes/` 目录
- 设计文档：统计 `design/gdd/` 中的markdown文件数量
- 生产工件：检查 `production/sprints/` 或 `production/milestones/`
- 记忆宫殿状态：检查 `.learnings/` 和 `.knowledge/` 目录

**存储检测结果**供后续路由使用，不要主动展示给用户。

### 阶段3：询问用户当前位置

使用 `AskUserQuestion` 工具，提供以下选项：

**问题**："欢迎使用记忆宫殿+游戏工作室！在推荐任何内容之前，我想了解你的起点。你现在处于哪个阶段？"

**选项**：
- `A) 还没有想法` — 我还没有游戏概念，想要探索和理解做什么
- `B) 模糊想法` — 我有个大致方向（比如"修仙题材"、"回合制战斗"），但不具体
- `C) 清晰概念` — 我知道核心玩法、类型，但还没写成文档
- `D) 已有工作` — 我已经有设计文档、原型或代码，想要继续或整理

等待用户选择，不要自动继续。

### 阶段4：根据回答路由

#### 如果选A：还没有想法

1. 确认从零开始完全没问题
2. 解释 `/brainstorm` 的作用（使用MDA框架、玩家心理学进行引导式创意）
3. 推荐路径：

```
概念阶段：
  /brainstorm open → 发现游戏概念
  /setup-engine → 配置引擎
  /art-bible → 定义视觉风格
  /map-systems → 分解概念为系统
  /design-system → 为每个系统编写GDD
  /review-all-gdds → 跨系统一致性检查
  /gate-check → 验证是否可进入架构阶段

架构阶段：
  /create-architecture → 主架构文档
  /architecture-decision (×N) → 记录技术决策(至少3个ADR)
  /create-control-manifest → 编译为可执行规则
  /architecture-review → 验证架构完整性

预生产：
  /ux-design → UX规格
  /prototype → 核心玩法原型
  /playtest-report → 测试报告
  /create-epics → 创建史诗
  /create-stories → 分解为故事
  /sprint-plan → 冲刺计划

生产阶段：→ 用 /dev-story 实现故事
```

4. 推荐下一步：`/brainstorm open`

#### 如果选B：模糊想法

1. 请用户分享模糊想法，几个词就够了
2. 验证这个想法作为起点
3. 推荐 `/brainstorm [他们的提示]` 来发展想法
4. 显示推荐路径（同A，但第一步改为 `/brainstorm [hint]`）

#### 如果选C：清晰概念

1. 请用户用一句话描述概念 - 类型和核心机制
2. 确认后提供两个路径：
   - `先形式化` → 运行 `/brainstorm [概念]` 结构化为正式文档
   - `直接开始` → 进入 `/setup-engine` 然后手动写GDD
3. 显示推荐路径（同A，但从他们选择的步骤开始）

#### 如果选D：已有工作

1. 分享阶段2的发现：
   - "我看到你有 [X个源文件 / Y个设计文档 / Z个原型]..."
   - "你的引擎 [已配置为X / 尚未配置]..."

2. **子情况D1 - 早期阶段**（引擎未配置或只有概念）：
   - 如果引擎未配置，推荐 `/setup-engine`
   - 然后运行 `/project-stage-detect` 检查缺口

3. **子情况D2 - GDD/ADR/故事已存在**：
   - 解释："有文件不等于符合模板格式。GDD可能缺少必需部分。`/adopt` 专门检查这个。"
   - 推荐：
     1. `/project-stage-detect` - 理解阶段和缺失内容
     2. `/adopt` - 审计现有工件格式

### 阶段5：设置审查模式

检查 `production/review-mode.txt` 是否存在。

**如果存在**：读取并显示当前模式，继续阶段6。

**如果不存在**：使用 `AskUserQuestion`：

**问题**："一个设置选择：你希望在工作流中进行多少设计审查？"

**选项**：
- `完整` — 每个关键步骤都有总监审查。适合团队或学习
- `精简（推荐）` — 仅在阶段门控(/gate-check)时审查。适合独立开发者
- `单人` — 无审查。最快速度。适合Game Jam或原型

将选择写入 `production/review-mode.txt`。

### 阶段6：记忆宫殿经验加载

在开始工作前，加载记忆宫殿的相关经验：

1. 读取 `.learnings/LEARNINGS.md` 中的 [GAME_BEST] 和 [GAME_IMPROVE] 条目
2. 读取 `.knowledge/mistakes/` 中的预防措施
3. 将这些经验作为约束条件应用到后续工作中

### 阶段7：确认并交接

使用 `AskUserQuestion` 询问用户想从哪一步开始：

**问题**："你想从 [推荐的第一步] 开始吗？"

**选项**：
- `是的，从 [推荐步骤] 开始`
- `我想先做别的`

用户确认后，回复："输入 `[skill命令]` 开始。"

## 边缘情况处理

- **用户选D但项目为空**：温和重定向 - "看起来项目还是空模板。A或B路径更适合？"
- **用户选A但项目有代码**：提及发现 - "我注意到 `src/` 已有代码。你意思是选D（已有工作）？"
- **用户是返回者**（引擎已配置，概念存在）：跳过引导 - "你已设置好！引擎是[X]，概念在 `design/gdd/game-concept.md`。想继续之前的工作吗？试试 `/sprint-plan` 或告诉我你想做什么。"
- **用户不符合任何选项**：让用户描述情况并适应。

## 协作协议

1. **先问** - 永远不要假设用户状态或意图
2. **提供选项** - 给出清晰路径，不是命令
3. **用户决定** - 他们选择方向
4. **不自动执行** - 推荐下一步，不未经询问就运行
5. **适应** - 如果用户情况不符合模板，倾听并调整

## 与记忆宫殿的集成点

| 集成点 | 说明 |
|-------|------|
| 场景识别 | registry.json 的 scenes 配置决定激活模式 |
| 规则加载 | 根据场景自动加载对应规则文件 |
| 知识加载 | 根据场景加载对应知识文件 |
| 错误预防 | mistakes/ 目录作为预防清单 |
| 经验记录 | 每次Skill执行后记录到 .learnings/ |
| 目标驱动 | tasks/task-pool.json 驱动Sprint计划 |
